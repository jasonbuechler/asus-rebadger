﻿    write-host "Immediately executing TFTP transfer via subnet 29..."
    
    tftp -i 192.168.29.1 put TM-AC1900_3.0.0.4_376_1703-g0ffdbba.trx